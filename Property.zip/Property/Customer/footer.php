<div class="footer">
     <div class="text"> |Anjali and Preethi|<br>happyhomes@gmail.com</a> </div>

   </div>
