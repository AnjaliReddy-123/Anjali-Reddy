<div class="footer">
     <div class="text"> |Anjali and Preethi|<br>happyhomes@gmail.com</div>

   </div>
